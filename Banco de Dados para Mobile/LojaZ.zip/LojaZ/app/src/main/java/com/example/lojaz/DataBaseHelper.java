package com.example.lojaz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static final String banco_dados = "Produtos";
    private  static  int versao = 1;

    public DataBaseHelper(Context context){
        super(context, banco_dados, null, versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL( "CREATE TABLE PRODUTO (ID INTEGER PRIMARY KEY,"+
                "NOME VARCHAR(30)," +
                "PRECO VARCHAR(15))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addProduto(Produto p){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("NOME",p.getNome());
        values.put("PRECO",p.getPreco());

        db.insert("PRODUTO",null, values);
    }

    public Produto getProduto(int id){
        SQLiteDatabase db = this.getReadableDatabase();

        Produto produto = new Produto();

        // Um cursor representa o resultado de uma query (busca)
        // e aponta para a linha selecionada
        Cursor cursor =
                db.rawQuery("SELECT * FROM PRODUTO WHERE ID = ?", new String[]{String.valueOf(id)});

        if(cursor.getCount() > 0){ //getCount retorna o número de elementos da consulta
            cursor.moveToFirst();
            produto.setId(cursor.getInt(0));
            produto.setNome(cursor.getString(1));
            produto.setPreco(cursor.getString(2));
        }else{
            produto.setId(0);
            produto.setNome("");
            produto.setPreco("");
        }

        return produto;
    }

    public int deleteProduto(){
        SQLiteDatabase db = this.getWritableDatabase();
        int i = db.delete("PRODUTO","1",null);

        return i;
    }
}
