package com.example.lojaz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText nome, preco, id;
    String idaux;
    Integer ID_PRODUTO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        id = findViewById(R.id.edtId);
        nome = findViewById(R.id.edtNomeProduto);
        preco = findViewById(R.id.edtPreco);
    }

    public void salvarProduto(View view) {

        try {
            Produto p = new Produto();

            p.setNome(nome.getText().toString());
            p.setPreco(preco.getText().toString());

            DataBaseHelper helper = new DataBaseHelper(this);
            helper.addProduto(p);

            Toast.makeText(this, p.getNome() + " foi adicionado com sucesso", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao adicionar!", Toast.LENGTH_SHORT).show();
        }

    }

    public void pesquisarProduto(View view){
        DataBaseHelper dbh = new DataBaseHelper(this);

        idaux = id.getText().toString();

        if (idaux.equals("")) {
            Toast.makeText(this, "Coloque um código", Toast.LENGTH_LONG).show();
        } else {
            ID_PRODUTO = Integer.parseInt(idaux);
            Produto p = dbh.getProduto(ID_PRODUTO);

            if (p.getNome().equals("")) {
                id.setText("");
                nome.setText("");
                preco.setText("");

                Toast.makeText(this, "Registro não localizado!", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    nome.setText(p.getNome());
                    preco.setText(p.getPreco());
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Erro ao buscar!", Toast.LENGTH_SHORT).show();
                }
            }

        }
    }

    public void limparProdutos(View view) {
        DataBaseHelper helper = new DataBaseHelper(this);
        int i = helper.deleteProduto();

        Toast.makeText(this, "deletou " + i + " produtos", Toast.LENGTH_SHORT).show();
    }
}